<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
include "config.php";
$r = mysqli_query($conn, "SELECT * FROM events ORDER BY id DESC");
$out = [];
while($row = mysqli_fetch_assoc($r)) $out[] = $row;
echo json_encode($out);
?>
