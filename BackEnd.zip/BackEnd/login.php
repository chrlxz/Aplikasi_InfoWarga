<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
include "config.php";
$input = json_decode(file_get_contents("php://input"), true);
$username = $_POST['username'] ?? $input['username'] ?? null;
$password = $_POST['password'] ?? $input['password'] ?? null;
if (!$username || !$password) {
    echo json_encode(["status"=>"error","message"=>"Username atau password tidak dikirim"]);
    exit;
}
$q = mysqli_query($conn, "SELECT * FROM users WHERE username='".mysqli_real_escape_string($conn,$username)."' AND password='".mysqli_real_escape_string($conn,$password)."'");
if (!$q || mysqli_num_rows($q) == 0) {
    echo json_encode(["status"=>"error","message"=>"Akun tidak ditemukan"]);
    exit;
}
$d = mysqli_fetch_assoc($q);
echo json_encode(["status"=>"success","message"=>"Login berhasil","role"=>$d["role"],"user"=>$d]);
?>
