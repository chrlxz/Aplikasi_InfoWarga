<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
include "config.php";

$username = $_POST['username'] ?? null;
$password = $_POST['password'] ?? null;
$nama     = $_POST['nama'] ?? null;
$telepon  = $_POST['telepon'] ?? null;
$role     = $_POST['role'] ?? 'user';

if (!$username || !$password || !$nama) {
    echo json_encode(["status"=>"error","message"=>"Data belum lengkap"]);
    exit;
}

$cek = mysqli_query($conn, "SELECT * FROM users WHERE username='".mysqli_real_escape_string($conn,$username)."'");
if (mysqli_num_rows($cek) > 0) {
    echo json_encode(["status"=>"error","message"=>"Username sudah digunakan"]);
    exit;
}

$q = mysqli_query($conn, "INSERT INTO users (username, password, nama, role, telepon) VALUES ('".mysqli_real_escape_string($conn,$username)."','".mysqli_real_escape_string($conn,$password)."','".mysqli_real_escape_string($conn,$nama)."','".mysqli_real_escape_string($conn,$role)."','".mysqli_real_escape_string($conn,$telepon)."')");

if ($q) echo json_encode(["status"=>"success","message"=>"Registrasi berhasil"]);
else echo json_encode(["status"=>"error","message"=>"Gagal menyimpan"]);
?>
