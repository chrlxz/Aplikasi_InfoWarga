<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
include "config.php";
$title = $_POST['title'] ?? null;
$date = $_POST['date'] ?? null;
$location = $_POST['location'] ?? null;
if (!$title) { echo json_encode(['status'=>'error','message'=>'Title required']); exit; }
$q = mysqli_query($conn, "INSERT INTO events (title, date, location) VALUES ('".mysqli_real_escape_string($conn,$title)."','".mysqli_real_escape_string($conn,$date)."','".mysqli_real_escape_string($conn,$location)."')");
if ($q) echo json_encode(['status'=>'success']); else echo json_encode(['status'=>'error']);
?>
