<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
include "config.php";
$title = $_POST['title'] ?? null;
$description = $_POST['description'] ?? null;
if (!$title) { echo json_encode(['status'=>'error','message'=>'Title required']); exit; }
$q = mysqli_query($conn, "INSERT INTO announcements (title, description) VALUES ('".mysqli_real_escape_string($conn,$title)."','".mysqli_real_escape_string($conn,$description)."')");
if ($q) echo json_encode(['status'=>'success']); else echo json_encode(['status'=>'error']);
?>
