<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
$target_dir = "uploads/";
if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);
if (!isset($_FILES['photo'])) { echo json_encode(['status'=>'error','message'=>'photo not sent']); exit; }
$fn = basename($_FILES['photo']['name']);
$target_file = $target_dir . time() . "_" . preg_replace('/[^a-zA-Z0-9._-]/', '_', $fn);
if (move_uploaded_file($_FILES['photo']['tmp_name'], $target_file)) {
    echo json_encode(['status'=>'success','path'=>$target_file]);
} else {
    echo json_encode(['status'=>'error','message'=>'upload failed']);
}
?>
