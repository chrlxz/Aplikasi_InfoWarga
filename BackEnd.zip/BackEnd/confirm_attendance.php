<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
include "config.php";

$user_id = $_POST['user_id'] ?? null;
$event_id = $_POST['event_id'] ?? null;
$status = $_POST['status'] ?? null;

if (!$user_id || !$event_id || !$status) {
    echo json_encode(["status"=>"error","message"=>"Data belum lengkap"]);
    exit;
}

$q = mysqli_query($conn,
    "INSERT INTO attendance (user_id, event_id, status) 
     VALUES ('$user_id', '$event_id', '$status')"
);

if ($q) echo json_encode(["status"=>"success"]);
else echo json_encode(["status"=>"error"]);
?>
